import 'package:form/Controllers/issue_tracker_Controller.dart';
import 'package:form/Controllers/networ_Controller.dart';
import 'package:form/Controllers/offlineHandler.dart';
import 'package:form/Controllers/pendingExpenses_Controller.dart';
import 'package:form/Controllers/school_Controller.dart';
import 'package:get/get.dart';

class HomeBinding implements Bindings {
  @override
  Future<void> dependencies() async {
    Get.lazyPut<OfflineHandler>(() => OfflineHandler());
    Get.lazyPut<GetXNetworkManager>(() => GetXNetworkManager());
    Get.lazyPut<PendingController>(() => PendingController());
    Get.lazyPut<StateController>(() => StateController());
    Get.lazyPut<DistrictController>(() => DistrictController());
    Get.lazyPut<BlockController>(() => BlockController());

    Get.lazyPut<IssueTrackerController>(() => IssueTrackerController());

    Get.lazyPut<SchoolController>(() => SchoolController());
    Get.lazyPut<StaffController>(() => StaffController());
  }
}
