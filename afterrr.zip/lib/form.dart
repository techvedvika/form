// ignore_for_file: deprecated_member_use, avoid_print

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:form/Controllers/networ_Controller.dart';
import 'package:form/Controllers/offlineHandler.dart';
import 'package:form/Controllers/pendingExpenses_Controller.dart';
import 'package:form/Model/expense_model.dart';
import 'package:form/confirm_dialog.dart';
import 'package:form/data.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'Controllers/school_Controller.dart';
import 'colors.dart';
import 'package:http/http.dart' as http;
import 'custom_dialog.dart';
import 'home_screen.dart';
import 'image_view.dart';
import 'my_text.dart';

final OfflineHandler _offlineHandler = Get.put(OfflineHandler());
final PendingController _pendingController = Get.put(PendingController());
final StaffController _staffController = Get.put(StaffController());
final AuthorityController _authController = Get.put(AuthorityController());

//Create 3 new users
//Office name By Default

//Paid Amount should Not be greater than Invoice Amount(Warning)
//Pending

//Validation on every Field

class Form1 extends StatefulWidget {
  const Form1({Key? key}) : super(key: key);

  @override
  Form1State createState() => Form1State();
}

TextEditingController _officeController = TextEditingController();

class Form1State extends State<Form1> {
  @override
  void initState() {
    super.initState();
    _officeController.text = GetStorage().read('office').toString();
    _expenseApprovedBy = '';
    _paymentApprovedBy = '';
    _officeName = DateFormat('dd-MM-yyyy').format(DateTime.now());
  }

  // String? _selectedState;
  String? _officeName;
  String? _expenseHead;
  String? _project;
  String? _sponsor;
  String? _expenseBy;
  String? _expenseApprovedBy;
  String? _imagePicked;
  String? _paidBy;
  String? _paymentApprovedBy;
  String? _paymentMode;
  String? _paymentType;

  //bool _validateState = false;
  bool _validateoffice = false;
  bool _validateSubmitDate = false;
  bool _validateTourId = false;
  bool _validateVendor = false;
  bool _validateInvoiceNo = false;
  bool _validateInvoiceDate = false;
  bool _validateInvoiceAmount = false;
  bool _validateTowards = false;
  bool _validatePaymentDate = false;
  bool _validateExpenseHead = false;
  bool _validateProject = false;
  bool _validateSponsor = false;
  bool _validateExpenseBy = false;
  bool _validateExpenseApprovedBy = false;
  bool _validateImagePicked = false;
  bool _validatePaidBy = false;
  bool _validatePaymentApprovedBy = false;
  bool _validatePaidAmount = false;
  bool _validatePaymentMode = false;
  bool _validatePaymentType = false;
  bool _validateAmount = false;
  bool _settleAmount = false;
  bool _partialAmount = false;
  var isLoading = false.obs;

  DateTime selectedDate = DateTime.now(), initialDate = DateTime.now();

  _selectDate(BuildContext context, TextEditingController date) async {
    final DateTime? selected = await showDatePicker(
      locale: const Locale('en', 'IN'),
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2015),
      lastDate: DateTime.now(),
      builder: (context, picker) {
        return Theme(
            data: Theme.of(context)
                .copyWith(colorScheme: const ColorScheme.light()),
            child: picker!);
      },
    );
    if (selected != null) {
      setState(() {
        selectedDate = selected;
        String formattedDate = DateFormat('dd-MM-yyyy').format(selectedDate);
        date.text = formattedDate;
      });
    }
  }

  PickedFile? _imageFile;
  final ImagePicker _picker = ImagePicker();
  File? _image;

  Future<String> takePhoto(ImageSource source) async {
    final pickedFile = await _picker.getImage(
      source: source,
      imageQuality: 10,
    );
    _imageFile = pickedFile.obs();

    _image = File(_imageFile!.path);
    final bytes = _image!.readAsBytesSync();

    String status = base64Encode(_image!.readAsBytesSync());

    return status;
  }

  final TextEditingController _submitDateController = TextEditingController();
  final TextEditingController _tourIdController = TextEditingController();
  final TextEditingController _vendorNameController = TextEditingController();
  final TextEditingController _invoiceNoController = TextEditingController();
  final TextEditingController _invoiceDateController = TextEditingController();
  final TextEditingController _invoiceAmountController =
      TextEditingController();
  final TextEditingController _towardsOfController = TextEditingController();
  final TextEditingController _paymentDateController = TextEditingController();
  final TextEditingController _paidAmountController = TextEditingController();
  final TextEditingController _imageController = TextEditingController();

  final FocusNode _tourNode = FocusNode();
  final FocusNode _vendorNode = FocusNode();
  final FocusNode _invoiceNode = FocusNode();
  final FocusNode _invoiceAmountNode = FocusNode();
  final FocusNode _towardsNode = FocusNode();

  Widget bottomSheet(BuildContext context) {
    return Container(
      color: MyColors.primary,
      height: 100,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 20,
      ),
      child: Column(
        children: <Widget>[
          const Text(
            "Select Image",
            style: TextStyle(fontSize: 20.0, color: Colors.white),
          ),
          const SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              FlatButton.icon(
                onPressed: () async {
                  _imagePicked = await takePhoto(
                    ImageSource.camera,
                  );

                  // uploadFile(userdata.read('customerID'));
                  Navigator.pop(context);
                  setState(() {});
                },
                icon: const Icon(
                  Icons.camera,
                  color: Colors.white,
                ),
                label: const Text(
                  'Camera',
                  style: TextStyle(fontSize: 20.0, color: Colors.white),
                ),
              ),
              FlatButton.icon(
                onPressed: () async {
                  _imagePicked = await takePhoto(ImageSource.gallery);

                  Navigator.pop(context);
                  setState(() {});
                },
                icon: const Icon(
                  Icons.image,
                  color: Colors.white,
                ),
                label: const Text(
                  'Gallery',
                  style: TextStyle(fontSize: 20.0, color: Colors.white),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<GetXNetworkManager>(
        init: GetXNetworkManager(),
        builder: (networkManager) {
          return Scaffold(
            backgroundColor: MyColors.grey_5,
            appBar: AppBar(
              backgroundColor: const Color(0xFF8A2724),
              title: const Text(
                'Expense Form',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
              ),
            ),
            body: Obx(
              () => isLoading.value || _staffController.isLoading.value
                  ? Stack(
                      children: [
                        Center(
                          child: Container(
                              color: Colors.white,
                              child: Center(
                                  child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Image.asset(
                                    'assets/17000ft.jpg',
                                    height: 60,
                                    width: 60,
                                  ),
                                  const CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                        MyColors.primary),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  const Text('Please wait...',
                                      style: TextStyle(
                                        decoration: TextDecoration.none,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                      ))
                                ],
                              ))),
                        )
                      ],
                    )
                  : SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      scrollDirection: Axis.vertical,
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(height: 5),
                            const Text('Center:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: TextField(
                                readOnly: true,
                                maxLines: 1,
                                controller: _officeController
                                  ..text = GetStorage().read('office'),
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(-12),
                                    border: InputBorder.none,
                                    hintText: "Office Name",
                                    hintStyle: MyText.body1(context)!
                                        .copyWith(color: MyColors.grey_40)),
                              ),
                            ),
                            _validateoffice
                                ? const Text('Please fill Office name',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Tour ID:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: TextField(
                                textInputAction: TextInputAction.next,
                                onSubmitted: (value) {
                                  FocusScope.of(context)
                                      .requestFocus(_vendorNode);
                                },
                                focusNode: _tourNode,
                                maxLines: 1,
                                controller: _tourIdController,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(-12),
                                    border: InputBorder.none,
                                    hintText: "Tour ID",
                                    hintStyle: MyText.body1(context)!
                                        .copyWith(color: MyColors.grey_40)),
                              ),
                            ),
                            _validateTourId
                                ? const Text('Please fill Tour Id',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Vendor Name:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: TextField(
                                onSubmitted: (value) {
                                  FocusScope.of(context)
                                      .requestFocus(_invoiceNode);
                                },
                                focusNode: _vendorNode,
                                textInputAction: TextInputAction.next,
                                maxLines: 1,
                                controller: _vendorNameController,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(-12),
                                    border: InputBorder.none,
                                    hintText: "Vendor Name",
                                    hintStyle: MyText.body1(context)!
                                        .copyWith(color: MyColors.grey_40)),
                              ),
                            ),
                            _validateVendor
                                ? const Text('Please fill Vendor name',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Invoice No:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: TextField(
                                focusNode: _invoiceNode,
                                textInputAction: TextInputAction.next,
                                maxLines: 1,
                                controller: _invoiceNoController,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(-12),
                                    border: InputBorder.none,
                                    hintText: "Invoice No:",
                                    hintStyle: MyText.body1(context)!
                                        .copyWith(color: MyColors.grey_40)),
                              ),
                            ),
                            _validateInvoiceNo
                                ? const Text('Please fill Invoice No',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Date of Invoice:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Row(
                                children: <Widget>[
                                  Container(width: 15),
                                  Expanded(
                                    child: TextField(
                                      onChanged: (value) => setState(() {}),
                                      readOnly: true,
                                      onTap: () {
                                        _selectDate(
                                            context, _invoiceDateController);
                                      },
                                      maxLines: 1,
                                      keyboardType: TextInputType.datetime,
                                      controller: _invoiceDateController,
                                      decoration: InputDecoration(
                                          contentPadding:
                                              const EdgeInsets.all(-12),
                                          border: InputBorder.none,
                                          hintText:
                                              "Date of Invoice(dd-mm-yyyy)",
                                          hintStyle: MyText.body1(context)!
                                              .copyWith(
                                                  color: MyColors.grey_40)),
                                    ),
                                  ),
                                  IconButton(
                                      onPressed: () {
                                        FocusScopeNode currentFocus =
                                            FocusScope.of(context);

                                        if (!currentFocus.hasPrimaryFocus) {
                                          currentFocus.unfocus();
                                        }
                                        _selectDate(
                                            context, _invoiceDateController);
                                      },
                                      icon: const Icon(Icons.calendar_today,
                                          color: MyColors.grey_40))
                                ],
                              ),
                            ),
                            _validateInvoiceDate
                                ? const Text('Please select date',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Invoice Amount:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: TextField(
                                onSubmitted: (value) {
                                  FocusScope.of(context)
                                      .requestFocus(_towardsNode);
                                },
                                focusNode: _invoiceAmountNode,
                                textInputAction: TextInputAction.next,
                                maxLines: 1,
                                inputFormatters: [
                                  FilteringTextInputFormatter.allow(
                                      RegExp('[0-9.,]+')),
                                ],
                                keyboardType:
                                    const TextInputType.numberWithOptions(
                                        decimal: true),
                                controller: _invoiceAmountController,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(-12),
                                    border: InputBorder.none,
                                    hintText: "Invoice Amount",
                                    hintStyle: MyText.body1(context)!
                                        .copyWith(color: MyColors.grey_40)),
                              ),
                            ),
                            _validateInvoiceAmount
                                ? const Text('Please fill Amount',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Expense Description:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: TextField(
                                focusNode: _towardsNode,
                                textInputAction: TextInputAction.next,
                                maxLines: 1,
                                controller: _towardsOfController,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.all(-12),
                                    border: InputBorder.none,
                                    hintText: "Expense Description:",
                                    hintStyle: MyText.body1(context)!
                                        .copyWith(color: MyColors.grey_40)),
                              ),
                            ),
                            _validateTowards
                                ? const Text('Please fill Towards Cost of',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Expense Head:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: InkWell(
                                splashColor: Colors.grey,
                                child: DropdownButton<String>(
                                  value: _expenseHead,
                                  iconSize: 24,
                                  elevation: 2,
                                  items: schoolController.expensehead!
                                      .map((value) {
                                    return DropdownMenuItem<String>(
                                      value: value.expenseheadname.toString(),
                                      child: Text(
                                          value.expenseheadname.toString()),
                                    );
                                  }).toList(),
                                  onChanged: (String? v) {
                                    FocusScope.of(context)
                                        .requestFocus(FocusNode());
                                    setState(() => _expenseHead = v);
                                  },
                                  isExpanded: true,
                                  hint: Text("Expense Head",
                                      style: MyText.body1(context)!
                                          .copyWith(color: MyColors.grey_40)),
                                  iconDisabledColor: Colors.black,
                                ),
                                onTap: () {
                                  FocusScope.of(context)
                                      .requestFocus(FocusNode());
                                },
                              ),
                            ),
                            _validateExpenseHead
                                ? const Text('Please select a Expense Head',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Programme Name:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: InkWell(
                                splashColor: Colors.grey,
                                child: DropdownButton<String>(
                                  value: _project,
                                  iconSize: 24,
                                  elevation: 2,
                                  items: DataModel()
                                      .programName
                                      .map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                  onChanged: (dynamic v) {
                                    setState(() {
                                      _project = v;
                                    });
                                  },
                                  isExpanded: true,
                                  hint: Text("Select Programme",
                                      style: MyText.body1(context)!
                                          .copyWith(color: MyColors.grey_40)),
                                  iconDisabledColor: Colors.black,
                                ),
                                onTap: () {},
                              ),
                            ),
                            _validateProject
                                ? const Text('Please select a programme',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Expense By:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: InkWell(
                                splashColor: Colors.grey,
                                child: DropdownButton<String>(
                                  value: _expenseBy,
                                  iconSize: 24,
                                  elevation: 2,
                                  items: _staffController.staffList.data!
                                      .where((element) =>
                                          element.location!.toLowerCase() ==
                                              _officeController.text
                                                  .toLowerCase() ||
                                          element.firstName!.toLowerCase() ==
                                              'sandeep' ||
                                          element.firstName!.toLowerCase() ==
                                              'sujata')
                                      .map((value) {
                                    return DropdownMenuItem<String>(
                                      value: value.firstName! +
                                          " " +
                                          value.lastName!,
                                      child: Text(value.firstName! +
                                          ' ' +
                                          value.lastName!),
                                    );
                                  }).toList(),
                                  onChanged: (dynamic v) {
                                    setState(() {
                                      _expenseBy = v;
                                    });
                                  },
                                  isExpanded: true,
                                  hint: Text("Expense By",
                                      style: MyText.body1(context)!
                                          .copyWith(color: MyColors.grey_40)),
                                  iconDisabledColor: Colors.black,
                                ),
                                onTap: () {},
                              ),
                            ),
                            _validateExpenseBy
                                ? const Text('Please select Expense By',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Upload Image:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Row(
                                children: <Widget>[
                                  Container(width: 15),
                                  Expanded(
                                    child: TextField(
                                      readOnly: true,
                                      onTap: () {
                                        showModalBottomSheet(
                                            backgroundColor: MyColors.primary,
                                            context: context,
                                            builder: ((builder) =>
                                                bottomSheet(context)));
                                      },
                                      maxLines: 1,
                                      keyboardType: TextInputType.text,
                                      controller: _imageController,
                                      decoration: InputDecoration(
                                          contentPadding:
                                              const EdgeInsets.all(-12),
                                          border: InputBorder.none,
                                          hintText:
                                              "Upload Image of Invoice with Approval",
                                          hintStyle: MyText.body1(context)!
                                              .copyWith(
                                                  color: MyColors.grey_40)),
                                    ),
                                  ),
                                  CircleAvatar(
                                      radius: 55,
                                      backgroundColor: Colors.white,
                                      child: _image != null
                                          ? InkWell(
                                              onTap: () {
                                                Get.to(() =>
                                                    ImageView(image: _image!));
                                              },
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(50),
                                                child: Image.file(
                                                  _image!,
                                                  width: 100,
                                                  height: 100,
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                            )
                                          : Container()),
                                  IconButton(
                                      icon: const Icon(Icons.camera,
                                          color: MyColors.grey_40),
                                      onPressed: () {
                                        showModalBottomSheet(
                                            backgroundColor: MyColors.primary,
                                            context: context,
                                            builder: ((builder) =>
                                                bottomSheet(context)));
                                      }),
                                ],
                              ),
                            ),
                            _validateImagePicked
                                ? const Text('Upload Image',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            const Text('Type of Payment:',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: MyColors.grey_95)),
                            Container(height: 10),
                            Container(
                              height: 45,
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(4))),
                              alignment: Alignment.centerLeft,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 25),
                              child: InkWell(
                                splashColor: Colors.grey,
                                child: DropdownButton<String>(
                                  value: _paymentType,
                                  iconSize: 24,
                                  elevation: 2,
                                  items: DataModel()
                                      .paymentType
                                      .map((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                  onChanged: (dynamic v) {
                                    setState(() {
                                      if (_paymentType == 'Pending') {
                                        // _paidBy == 'null';
                                      }
                                      _paymentType = v;
                                    });
                                  },
                                  isExpanded: true,
                                  hint: Text("Type of Payment",
                                      style: MyText.body1(context)!
                                          .copyWith(color: MyColors.grey_40)),
                                  iconDisabledColor: Colors.black,
                                ),
                                onTap: () {
                                  setState(() {
                                    FocusScopeNode currentFocus =
                                        FocusScope.of(context);

                                    if (!currentFocus.hasPrimaryFocus) {
                                      currentFocus.unfocus();
                                    }
                                  });
                                },
                              ),
                            ),
                            _validatePaymentType
                                ? const Text('Please select Payment type',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            Container(height: 15),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : const Text('Date of Payment:',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: MyColors.grey_95)),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 10),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(
                                    height: 45,
                                    decoration: const BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(4))),
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: Row(
                                      children: <Widget>[
                                        Container(width: 15),
                                        Expanded(
                                          child: TextField(
                                            readOnly: true,
                                            onTap: () {
                                              if (_paymentType != 'Pending') {
                                                _selectDate(context,
                                                    _paymentDateController);
                                              }
                                            },
                                            onChanged: (dynamic v) {
                                              setState(() {
                                                if (_paymentType != 'Pending') {
                                                  _paymentDateController.text =
                                                      '';
                                                }
                                              });
                                            },
                                            maxLines: 1,
                                            keyboardType:
                                                TextInputType.datetime,
                                            controller: _paymentDateController,
                                            decoration: InputDecoration(
                                                contentPadding:
                                                    const EdgeInsets.all(-12),
                                                border: InputBorder.none,
                                                hintText:
                                                    "Date of Payment(dd-mm-yyyy)",
                                                hintStyle:
                                                    MyText.body1(context)!
                                                        .copyWith(
                                                            color: MyColors
                                                                .grey_40)),
                                          ),
                                        ),
                                        IconButton(
                                            onPressed: () {
                                              if (_paymentType != 'Pending') {
                                                _selectDate(context,
                                                    _paymentDateController);
                                              }
                                            },
                                            icon: const Icon(
                                                Icons.calendar_today,
                                                color: MyColors.grey_40))
                                      ],
                                    ),
                                  ),
                            _validatePaymentDate
                                ? const Text('Please select a date',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 15),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : const Text('Paid By:',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: MyColors.grey_95)),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 10),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(
                                    height: 45,
                                    decoration: const BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(4))),
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 25),
                                    child: InkWell(
                                      splashColor: Colors.grey,
                                      child: DropdownButton<String>(
                                        value: _paidBy,
                                        iconSize: 24,
                                        elevation: 2,
                                        items: _staffController.staffList.data!
                                            .where((element) =>
                                                element.location!
                                                        .toLowerCase() ==
                                                    _officeController.text
                                                        .toLowerCase() ||
                                                element.firstName!
                                                        .toLowerCase() ==
                                                    'sandeep' ||
                                                element.firstName!
                                                        .toLowerCase() ==
                                                    'sujata')
                                            .map((value) {
                                          return DropdownMenuItem<String>(
                                              value: value.firstName! +
                                                  " " +
                                                  value.lastName!,
                                              child: Text(value.firstName! +
                                                  ' ' +
                                                  value.lastName!)
                                              // value: value,
                                              // child: Text(value),
                                              );
                                        }).toList(),
                                        onChanged: (String? v) {
                                          setState(() {
                                            _paidBy = v;
                                          });
                                        },
                                        isExpanded: true,
                                        hint: Text("Paid By",
                                            style: MyText.body1(context)!
                                                .copyWith(
                                                    color: MyColors.grey_40)),
                                        iconDisabledColor: Colors.black,
                                      ),
                                      onTap: () {},
                                    ),
                                  ),
                            _validatePaidBy
                                ? const Text('Please fill Name',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 15),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 15),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : const Text('Paid Amount:',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: MyColors.grey_95)),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 10),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(
                                    height: 45,
                                    decoration: const BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(4))),
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 25),
                                    child: TextField(
                                      enabled: _paymentType == 'Pending'
                                          ? false
                                          : true,
                                      inputFormatters: [
                                        FilteringTextInputFormatter.allow(
                                            RegExp('[0-9.,]+')),
                                      ],
                                      maxLines: 1,
                                      keyboardType:
                                          const TextInputType.numberWithOptions(
                                              decimal: true),
                                      controller: _paidAmountController,
                                      decoration: InputDecoration(
                                          contentPadding:
                                              const EdgeInsets.all(-12),
                                          border: InputBorder.none,
                                          hintText: "Paid Amount",
                                          hintStyle: MyText.body1(context)!
                                              .copyWith(
                                                  color: MyColors.grey_40)),
                                    ),
                                  ),
                            _validatePaidAmount
                                ? const Text('Please fill Paid Amount',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            _validateAmount
                                ? const Text(
                                    '* Paid Amount Should not be greater than Invoice Amount',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            _partialAmount
                                ? const Text(
                                    '*You selected partial type of payment paid amount should be less than invoice amount',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            // _validateAmount
                            // ? const Text(
                            //     '*',
                            //     style: TextStyle(
                            //         fontSize: 12,
                            //         fontWeight: FontWeight.bold,
                            //         color: Colors.red))
                            // : const SizedBox(),

                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 15),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : const Text('Mode of Payment:',
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: MyColors.grey_95)),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(height: 10),
                            _paymentType == 'Pending'
                                ? const SizedBox()
                                : Container(
                                    height: 45,
                                    decoration: const BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(4))),
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 25),
                                    child: InkWell(
                                      splashColor: Colors.grey,
                                      child: DropdownButton<String>(
                                        value: _paymentMode,
                                        iconSize: 24,
                                        elevation: 2,
                                        items: DataModel()
                                            .paymentMode
                                            .map((String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value),
                                          );
                                        }).toList(),
                                        onChanged: (_paymentType == 'Pending'
                                                ? true
                                                : false)
                                            ? null
                                            : (dynamic v) {
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());

                                                setState(() {
                                                  if (_paymentType == 'Pending'
                                                      ? false
                                                      : true) {
                                                    _paymentMode = v;
                                                  } else {
                                                    _paymentMode = '';
                                                  }
                                                });
                                              },
                                        isExpanded: true,
                                        hint: Text("Mode of Payment",
                                            style: MyText.body1(context)!
                                                .copyWith(
                                                    color: MyColors.grey_40)),
                                        iconDisabledColor: Colors.black,
                                      ),
                                      onTap: () {
                                        FocusScope.of(context)
                                            .requestFocus(FocusNode());

                                        if (_paymentType == 'Pending'
                                            ? false
                                            : true) {
                                          _paymentMode = '';
                                        }
                                      },
                                    ),
                                  ),
                            _validatePaymentMode
                                ? const Text('Please select Payment Mode',
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))
                                : const SizedBox(),
                            const SizedBox(height: 10),
                            Container(height: 15),
                            SizedBox(
                              width: double.infinity,
                              height: 45,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    primary: const Color(0xFF8A2724),
                                    elevation: 0),
                                child: Text("SUBMIT",
                                    style: MyText.subhead(context)!
                                        .copyWith(color: Colors.white)),
                                onPressed: () async {
                                  setState(() {
                                    _officeController.text.isNotEmpty
                                        ? _validateoffice = false
                                        : _validateoffice = true;
                                    _tourIdController.text.isNotEmpty
                                        ? _validateTourId = false
                                        : _validateTourId = true;
                                    _vendorNameController.text.isNotEmpty
                                        ? _validateVendor = false
                                        : _validateVendor = true;
                                    _invoiceNoController.text.isNotEmpty
                                        ? _validateInvoiceNo = false
                                        : _validateInvoiceNo = true;

                                    _invoiceDateController.text.isNotEmpty
                                        ? _validateInvoiceDate = false
                                        : _validateInvoiceDate = true;
                                    _invoiceAmountController.text.isNotEmpty
                                        ? _validateInvoiceAmount = false
                                        : _validateInvoiceAmount = true;
                                    _towardsOfController.text.isNotEmpty
                                        ? _validateTowards = false
                                        : _validateTowards = true;
                                    _expenseHead != null
                                        ? _validateExpenseHead = false
                                        : _validateExpenseHead = true;
                                    // _project != null
                                    //     ? _validateProject = false
                                    //     : _validateProject = true;
                                    // _sponsor != null
                                    //     ? _validateSponsor = false
                                    //     : _validateSponsor = true;
                                    _expenseBy != null
                                        ? _validateExpenseBy = false
                                        : _validateExpenseBy = true;
                                    // _expenseApprovedBy != null
                                    //     ? _validateExpenseApprovedBy = false
                                    //     : _validateExpenseApprovedBy = true;
                                    _imagePicked != null
                                        ? _validateImagePicked = false
                                        : _validateImagePicked = true;
                                    _paymentDateController.text.isNotEmpty ||
                                            _paymentType == 'Pending'
                                        ? _validatePaymentDate = false
                                        : _validatePaymentDate = true;

                                    _paidBy != null || _paymentType == 'Pending'
                                        ? _validatePaidBy = false
                                        : _validatePaidBy = true;

                                    _paidAmountController.text.isNotEmpty ||
                                            _paymentType == 'Pending'
                                        ? _validatePaidAmount = false
                                        : _validatePaidAmount = true;
                                    _paymentType != null
                                        ? _validatePaymentType = false
                                        : _validatePaymentType = true;
                                    _paymentMode != null ||
                                            _paymentType == 'Pending'
                                        ? _validatePaymentMode = false
                                        : _validatePaymentMode = true;

                                    String _invoiceAmount =
                                        _invoiceAmountController.text;
                                    String _paidAmount =
                                        _paidAmountController.text;
                                    if (_paymentType != 'Pending') {
                                      double.parse(_invoiceAmount) <
                                              double.parse(_paidAmount)
                                          ? _validateAmount = true
                                          : _validateAmount = false;
                                    }
                                    // _paymentType == 'Pending' ?_validatePaymentDate= true : _validatePaymentDate=false;
                                    if (_paymentType == 'Settlement') {
                                      double.parse(_invoiceAmount) ==
                                              double.parse(_paidAmount)
                                          ? _settleAmount = false
                                          : _settleAmount = true;
                                    }
                                    if (_paymentType == 'Partial') {
                                      double.parse(_invoiceAmount) ==
                                              double.parse(_paidAmount)
                                          ? _partialAmount = true
                                          : _partialAmount = false;
                                    }

                                    if (_settleAmount &&
                                        double.parse(
                                                _invoiceAmountController.text) >
                                            double.parse(
                                                _paidAmountController.text)) {
                                      showDialog(
                                          context: context,
                                          builder: (_) => Confirmation(
                                              desc:
                                                  'You have selected settlement mode, your paid amount is less than invoice amount. Is it Okay?',
                                              title: 'Alert',
                                              onPressed: () async {
                                                setState(() {
                                                  _settleAmount = false;
                                                });

                                                if (!_validateAmount &&
                                                    !_settleAmount &&
                                                    !_validatePaymentMode &&
                                                    !_validatePaymentType &&
                                                    !_validatePaidAmount &&
                                                    //  !_validatePaymentApprovedBy &&
                                                    !_validateVendor &&
                                                    !_validatePaymentDate &&
                                                    !_validateTourId &&
                                                    !_validateImagePicked &&
                                                    //  !_validateExpenseApprovedBy &&
                                                    !_validateExpenseBy &&
                                                    !_validateExpenseHead &&
                                                    !_validatePaidBy &&
                                                    !_validateInvoiceAmount &&
                                                    !_validateInvoiceDate &&
                                                    !_validateInvoiceNo &&
                                                    !_validateTowards &&
                                                    !_partialAmount) {
                                                  print(
                                                      'validation is checked');
                                                  if (networkManager
                                                          .connectionType
                                                          .value !=
                                                      0) {
                                                    Navigator.of(context).pop();
                                                    print('ready to insert');
                                                    isLoading.value = true;
                                                    var rsp = await insertData(
                                                        _officeController.text,
                                                        _officeName!,
                                                        _tourIdController.text,
                                                        _vendorNameController
                                                            .text,
                                                        _invoiceNoController
                                                            .text,
                                                        _invoiceDateController
                                                            .text,
                                                        _invoiceAmountController
                                                            .text,
                                                        _towardsOfController
                                                            .text,
                                                        _expenseHead!,
                                                        _expenseBy!,
                                                        _expenseApprovedBy!,
                                                        _imagePicked!,
                                                        _paymentDateController
                                                            .text,
                                                        _paidBy!,
                                                        _paymentApprovedBy
                                                            .toString(),
                                                        _paidAmountController
                                                            .text,
                                                        _paymentType.toString(),
                                                        _paymentMode.toString(),
                                                        GetStorage()
                                                            .read('userId')
                                                            .toString());

                                                    if (rsp['status']
                                                            .toString() ==
                                                        '1') {
                                                      isLoading.value = false;
                                                      showDialog(
                                                          context: context,
                                                          builder: (_) =>
                                                              const CustomEventDialog());
                                                      setState(() {
                                                        _submitDateController
                                                            .clear();
                                                        _tourIdController
                                                            .clear();
                                                        _vendorNameController
                                                            .clear();
                                                        _invoiceNoController
                                                            .clear();
                                                        _invoiceDateController
                                                            .clear();
                                                        _invoiceAmountController
                                                            .clear();
                                                        _towardsOfController
                                                            .clear();
                                                        _imagePicked = null;
                                                        _expenseHead = null;
                                                        _expenseBy = null;
                                                        _expenseApprovedBy =
                                                            null;
                                                        _image = null;
                                                        _paymentDateController
                                                            .clear();
                                                        _paidBy = null;
                                                        _paymentApprovedBy =
                                                            null;
                                                        _paidAmountController
                                                            .clear();
                                                        _paymentType = null;
                                                        _paymentMode = null;
                                                        _officeController
                                                            .clear();
                                                      });
                                                    } else if (rsp['status']
                                                            .toString() ==
                                                        '0') {
                                                      isLoading.value = false;
                                                      showDialog(
                                                          context: context,
                                                          builder: (BuildContext
                                                              context) {
                                                            return AlertDialog(
                                                              title: const Text(
                                                                  'Something Went Wrong'),
                                                              content: const Text(
                                                                  'Try Again!!'),
                                                              actions: <Widget>[
                                                                FlatButton(
                                                                  child:
                                                                      const Text(
                                                                          'OK'),
                                                                  onPressed:
                                                                      () {
                                                                    Navigator.of(
                                                                            context)
                                                                        .pop();
                                                                  },
                                                                )
                                                              ],
                                                            );
                                                          });
                                                    } else {
                                                      isLoading.value = false;
                                                      showDialog(
                                                          context: context,
                                                          builder: (BuildContext
                                                              context) {
                                                            return AlertDialog(
                                                              title: const Text(
                                                                  'Something Went Wrong'),
                                                              content: const Text(
                                                                  'Try After Sometime!!'),
                                                              actions: <Widget>[
                                                                FlatButton(
                                                                  child:
                                                                      const Text(
                                                                          'OK'),
                                                                  onPressed:
                                                                      () {
                                                                    Navigator.of(
                                                                            context)
                                                                        .pop();
                                                                  },
                                                                )
                                                              ],
                                                            );
                                                          });
                                                    }
                                                  } else {
                                                    ExpenseModel
                                                        contactinfoModel =
                                                        ExpenseModel(
                                                      office: _officeController
                                                          .text
                                                          .toString(),
                                                      submissionDate:
                                                          _officeName!,
                                                      tourId: _tourIdController
                                                          .text
                                                          .toString(),
                                                      vendorName:
                                                          _vendorNameController
                                                              .text
                                                              .toString(),
                                                      invoiceNumber:
                                                          _invoiceNoController
                                                              .text
                                                              .toString(),
                                                      invoiceDate:
                                                          _invoiceDateController
                                                              .text
                                                              .toString(),
                                                      invoiceAmount:
                                                          _invoiceAmountController
                                                              .text
                                                              .toString(),
                                                      towardsCost:
                                                          _towardsOfController
                                                              .text
                                                              .toString(),
                                                      expenseHead: _expenseHead
                                                          .toString(),
                                                      expenseBy:
                                                          _expenseBy.toString(),
                                                      expenseApprovedBy:
                                                          _expenseApprovedBy
                                                              .toString(),
                                                      invoiceImage: _imagePicked
                                                          .toString(),
                                                      dateOfPayment:
                                                          _paymentDateController
                                                              .text
                                                              .toString(),
                                                      paidBy:
                                                          _paidBy.toString(),
                                                      paymentApprovedBy:
                                                          _paymentApprovedBy
                                                              .toString(),
                                                      paidAmount:
                                                          _paidAmountController
                                                              .text
                                                              .toString(),
                                                      paymentType: _paymentType
                                                          .toString(),
                                                      paymentMode: _paymentMode
                                                          .toString(),
                                                      userId: GetStorage()
                                                          .read('userId')
                                                          .toString(),
                                                    );

                                                    await Controller()
                                                        .addData(
                                                            contactinfoModel)
                                                        .then((value) {
                                                      if (value > 0) {
                                                        showDialog(
                                                            context: context,
                                                            builder: (_) =>
                                                                const CustomEventDialog(
                                                                  desc:
                                                                      'Data Submitted',
                                                                ));
                                                      } else {}
                                                    });

                                                    setState(() {
                                                      _submitDateController
                                                          .clear();
                                                      _tourIdController.clear();
                                                      _vendorNameController
                                                          .clear();
                                                      _invoiceNoController
                                                          .clear();
                                                      _invoiceDateController
                                                          .clear();
                                                      _invoiceAmountController
                                                          .clear();
                                                      _towardsOfController
                                                          .clear();
                                                      _expenseHead = null;
                                                      _expenseBy = null;
                                                      _expenseApprovedBy = null;
                                                      _image = null;
                                                      _imagePicked = null;
                                                      _paymentDateController
                                                          .clear();
                                                      _paidBy = null;
                                                      _paymentApprovedBy = null;
                                                      _paidAmountController
                                                          .clear();
                                                      _paymentType = null;
                                                      _paymentMode = null;
                                                      //   _selectedState = null;
                                                      _officeController.clear();
                                                    });
                                                  }
                                                }
                                              }));
                                    }
                                  });
                                  if (!_validateAmount &&
                                      !_settleAmount &&
                                      !_validatePaymentMode &&
                                      !_validatePaymentType &&
                                      !_validatePaidAmount &&
                                      !_validateVendor &&
                                      !_validatePaymentDate &&
                                      !_validateTourId &&
                                      !_validateImagePicked &&
                                      !_validateExpenseBy &&
                                      !_validateExpenseHead &&
                                      !_validatePaidBy &&
                                      !_validateInvoiceAmount &&
                                      !_validateInvoiceDate &&
                                      !_validateInvoiceNo &&
                                      !_validateTowards &&
                                      !_partialAmount) {
                                    if (networkManager.connectionType.value !=
                                        0) {
                                      //   try {

                                      isLoading.value = true;
                                      var rsp = await insertData(
                                          _officeController.text,
                                          _officeName!,
                                          _tourIdController.text,
                                          _vendorNameController.text,
                                          _invoiceNoController.text,
                                          _invoiceDateController.text,
                                          _invoiceAmountController.text,
                                          _towardsOfController.text,
                                          _expenseHead!,
                                          _expenseBy!,
                                          _expenseApprovedBy == null
                                              ? ''
                                              : _expenseApprovedBy!,
                                          _imagePicked!,
                                          _paymentDateController.text,
                                          _paidBy == null ? '' : _paidBy!,
                                          _paymentApprovedBy == null
                                              ? ''
                                              : _paymentApprovedBy!,
                                          _paidAmountController.text,
                                          _paymentType == null
                                              ? ''
                                              : _paymentType!,
                                          _paymentMode == null
                                              ? ''
                                              : _paymentMode!,
                                          GetStorage()
                                              .read('userId')
                                              .toString());

                                      if (rsp['status'].toString() == '1') {
                                        isLoading.value = false;
                                        showDialog(
                                            context: context,
                                            builder: (_) =>
                                                const CustomEventDialog());
                                        setState(() {
                                          _submitDateController.clear();
                                          _tourIdController.clear();
                                          _vendorNameController.clear();
                                          _invoiceNoController.clear();
                                          _invoiceDateController.clear();
                                          _invoiceAmountController.clear();
                                          _towardsOfController.clear();
                                          _expenseHead = null;
                                          _expenseBy = null;
                                          _expenseApprovedBy = null;
                                          _image = null;
                                          _imagePicked = null;
                                          _paymentDateController.clear();
                                          _paidBy = null;
                                          _paymentApprovedBy = null;
                                          _paidAmountController.clear();
                                          _paymentType = null;
                                          _paymentMode = null;
                                          _officeController.clear();
                                        });
                                      } else if (rsp['status'].toString() ==
                                          '0') {
                                        isLoading.value = false;
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                title: const Text(
                                                    'Something Went Wrong'),
                                                content:
                                                    const Text('Try Again!!'),
                                                actions: <Widget>[
                                                  FlatButton(
                                                    child: const Text('OK'),
                                                    onPressed: () {
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                  )
                                                ],
                                              );
                                            });
                                      } else {
                                        isLoading.value = false;
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                title: const Text(
                                                    'Something Went Wrong'),
                                                content: const Text(
                                                    'Try After Sometime!!'),
                                                actions: <Widget>[
                                                  FlatButton(
                                                    child: const Text('OK'),
                                                    onPressed: () {
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                  )
                                                ],
                                              );
                                            });
                                      }
                                    } else {
                                      ExpenseModel contactinfoModel =
                                          ExpenseModel(
                                        office:
                                            _officeController.text.toString(),
                                        submissionDate: _officeName!,
                                        tourId:
                                            _tourIdController.text.toString(),
                                        vendorName: _vendorNameController.text
                                            .toString(),
                                        invoiceNumber: _invoiceNoController.text
                                            .toString(),
                                        invoiceDate: _invoiceDateController.text
                                            .toString(),
                                        invoiceAmount: _invoiceAmountController
                                            .text
                                            .toString(),
                                        towardsCost: _towardsOfController.text
                                            .toString(),
                                        expenseHead: _expenseHead.toString(),
                                        expenseBy: _expenseBy.toString(),
                                        expenseApprovedBy:
                                            _expenseApprovedBy.toString(),
                                        invoiceImage: _imagePicked.toString(),
                                        dateOfPayment: _paymentDateController
                                            .text
                                            .toString(),
                                        paidBy: _paidBy.toString(),
                                        paymentApprovedBy:
                                            _paymentApprovedBy.toString(),
                                        paidAmount: _paidAmountController.text
                                            .toString(),
                                        paymentType: _paymentType.toString(),
                                        paymentMode: _paymentMode.toString(),
                                        userId: GetStorage()
                                            .read('userId')
                                            .toString(),
                                      );

                                      await Controller()
                                          .addData(contactinfoModel)
                                          .then((value) {
                                        if (value > 0) {
                                          showDialog(
                                              context: context,
                                              builder: (_) =>
                                                  const CustomEventDialog(
                                                    desc: 'Data Submitted',
                                                  ));
                                        } else {}
                                      });
                                      setState(() {
                                        _submitDateController.clear();
                                        _tourIdController.clear();
                                        _vendorNameController.clear();
                                        _invoiceNoController.clear();
                                        _invoiceDateController.clear();
                                        _invoiceAmountController.clear();
                                        _towardsOfController.clear();
                                        _expenseHead = null;
                                        _expenseBy = null;
                                        _expenseApprovedBy = null;
                                        _image = null;
                                        _imagePicked = null;
                                        _paymentDateController.clear();
                                        _paidBy = null;
                                        _paymentApprovedBy = null;
                                        _paidAmountController.clear();
                                        _paymentType = null;
                                        _paymentMode = null;
                                        //   _selectedState = null;
                                        _officeController.clear();
                                      });
                                    }
                                  }
                                },
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
            ),
          );
        });
  }
}

Future insertData(
    String office,
    String submission_date,
    String tour_id,
    String vendor_name,
    String invoice_no,
    String date_of_invoice,
    String invoice_amt,
    String towards_cost_of,
    String expense_head,
    String expense_by,
    String expense_approved_by,
    String image,
    String date_of_payment,
    String paid_by,
    String payment_approved_by,
    String paid_amt,
    String type_of_payment,
    String mode_of_payment,
    String userId) async {
  print('insert pending is called');
  print(office);
  print(submission_date);
  print(tour_id);
  print(vendor_name);
  print(invoice_no);
  print(date_of_invoice);
  print(invoice_amt);
  print(towards_cost_of);
  print(expense_head);
  print(expense_by);
  print(expense_approved_by);
  print(image);
  print(date_of_payment);
  print(paid_by);
  print(payment_approved_by);
  print(paid_amt);
  print(type_of_payment);
  print(mode_of_payment);
  print(userId);
  var response =
      await http.post(Uri.parse(MyColors.baseUrl + 'expense'), headers: {
    "Accept": "Application/json"
  }, body: {
    "office": office,
    "submission_date": submission_date,
    "tour_id": tour_id,
    "vendor_name": vendor_name,
    "invoice_no": invoice_no,
    "date_of_invoice": date_of_invoice,
    "invoice_amt": invoice_amt,
    "towards_cost_of": towards_cost_of,
    "expense_head": expense_head,

    // "project": project,
    // "sponsor": sponsor,
    "expense_by": expense_by,
    "expense_approved_by": expense_approved_by,
    "image": image,
    "date_of_payment": date_of_payment,
    "paid_by": paid_by,
    "payment_approved_by": payment_approved_by,
    "paid_amt": paid_amt,
    "type_of_payment": type_of_payment,
    "mode_of_payment": mode_of_payment,
    "uid": userId,
    "status": 'Pending'
  });
  var convertedDatatoJson = jsonDecode(response.body);
  return convertedDatatoJson;
}
