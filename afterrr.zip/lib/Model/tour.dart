// To parse this JSON data, do
//
//     final tourId = tourIdFromJson(jsonString);

import 'dart:convert';

List<TourId> tourIdFromJson(String str) =>
    List<TourId>.from(json.decode(str).map((x) => TourId.fromJson(x)));

String tourIdToJson(List<TourId> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class TourId {
  TourId({
    this.tourId,
  });

  String? tourId;

  factory TourId.fromJson(Map<String, dynamic> json) => TourId(
        tourId: json["tour_id"],
      );

  Map<String, dynamic> toJson() => {
        "tour_id": tourId,
      };
}
