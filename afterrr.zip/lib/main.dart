import 'dart:async';

import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:form/Controllers/HomeBinding.dart';
import 'package:get_storage/get_storage.dart';
import 'package:get/get.dart';

import 'home_screen.dart';
import 'login.dart';

Future<void> main() async {
  await GetStorage.init();
  await SqfliteDatabaseHelper.instance.db;

  runApp(MyApp());
  configLoading();
}

void configLoading() {
  EasyLoading.instance
    ..displayDuration = const Duration(milliseconds: 2000)
    ..indicatorType = EasyLoadingIndicatorType.fadingCircle
    ..loadingStyle = EasyLoadingStyle.dark
    ..indicatorSize = 45.0
    ..radius = 10.0
    ..progressColor = Colors.yellow
    ..backgroundColor = Colors.green
    ..indicatorColor = Colors.yellow
    ..textColor = Colors.yellow
    ..maskColor = Colors.blue.withOpacity(0.5)
    ..userInteractions = true
    ..dismissOnTap = false;
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final userdata = GetStorage();

  List? list;
  bool loading = true;
  // Future userList() async {
  //   list = await Controller().fetchData();
  //   setState(() {
  //     loading = false;
  //   });
  //   //print(list);
  // }

  // Future syncToMysql() async {
  //   await SyncronizationData().fetchAllInfo().then((userList) async {
  //     EasyLoading.show(status: 'Dont close app. we are sync...');
  //     await SyncronizationData().saveToMysqlWith(userList);
  //     EasyLoading.showSuccess('Successfully saved');
  //   });
  // }

  @override
  void initState() {
    super.initState();
    // userList();
   // isInteret();

    GetStorage().writeIfNull('isLogged', false);

    Future.delayed(Duration.zero, () async {
      checkLogged();
    });
  }

  final _inputKey = GlobalKey<FormState>();
  final _messangerKey = GlobalKey<ScaffoldMessengerState>();
  String inputText = "";

  String appendString() {
    setState(() {
      inputText += inputText;
    });
    return inputText;
  }

  // Future isInteret() async {
  //   await SyncronizationData.isInternet().then((connection) {
  //     if (connection) {

  //     } else {
  //       _messangerKey.currentState!.showSnackBar(const SnackBar(
  //         content:  Text('No internet connection'),
  //       ));
  //       //    .showSnackBar(const SnackBar(content: Text("No Internet")));
  //     }
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      scaffoldMessengerKey: _messangerKey,
      builder: EasyLoading.init(),

      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('in', 'IN'),
        Locale('en', 'US'),
      ],
      localeResolutionCallback: (locale, supportedLocales) {
        for (var supportedLocaleLanguage in supportedLocales) {
          if (supportedLocaleLanguage.languageCode == locale!.languageCode &&
              supportedLocaleLanguage.countryCode == locale.countryCode) {
            return supportedLocaleLanguage;
          }
        }
        return supportedLocales.first;
      },
      locale: const Locale('in'),

      debugShowCheckedModeBanner: false,
      theme: ThemeData(),
      initialBinding: HomeBinding(),
      home: AnimatedSplashScreen(
        splash: Container(
            decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
              'assets/logo.png',
            ),
          ),
        )),
        // child: Image.asset('assets/logo.png', height: 500, width: 500)),
        nextScreen: Signin2Page(),
        splashTransition: SplashTransition.rotationTransition,
        backgroundColor: Colors.white,
        duration: 18000,
        // curve: Curves.easeInOutCubicEmphasized,
      ),

      //Signin2Page(),
    );
  }

  void checkLogged() async {
    GetStorage().read('isLogged')
        ? Get.offAll(() => const HomeScreen())
        : Get.offAll(() => Signin2Page());
  }
}
